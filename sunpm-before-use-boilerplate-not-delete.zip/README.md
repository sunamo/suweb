Shared package for npmjs.org.
